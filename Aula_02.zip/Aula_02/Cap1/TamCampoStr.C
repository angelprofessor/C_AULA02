/* TamCampoStr.C */
/* Tamanho de campo com cadeias de caracteres */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
    printf("\nOBJETO       %12s","CODIGO");
    printf("\nLapis        %12s","WQR");
    printf("\nBorrachas    %12s","ASO");
    printf("\nCanetas      %12s","KPX");
    printf("\nCadernos     %12s","FJI");
    printf("\nFitas        %12s","TYE");
    system("PAUSE");	
    return 0;			
}




