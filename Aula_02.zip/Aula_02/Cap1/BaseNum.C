/* BaseNum.C */
/* Definindo a base num�rica */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
    printf("\n%d",65);
    printf("\n%x",65);
    printf("\n%o",65);
    printf("\n%c",65);
    system("PAUSE");	
    return 0;			
}




