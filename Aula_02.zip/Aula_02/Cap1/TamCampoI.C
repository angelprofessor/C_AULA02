/* TamCampoI.C */
/* Tamanho de campo com inteiros */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
    int lapis=45, borrachas=2345, canetas=420, cadernos=8,fitas=13050;
    printf("\nLapis        %12d",lapis);
    printf("\nBorrachas    %12d",borrachas);
    printf("\nCanetas      %12d",canetas);
    printf("\nCadernos     %12d",cadernos);
    printf("\nFitas        %12d",fitas);
    system("PAUSE");	
    return 0;			
}



