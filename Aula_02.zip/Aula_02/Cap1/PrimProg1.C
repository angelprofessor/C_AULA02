/*Esse programa mostra o uso de coment�rios em v�rias linhas  *
  e mostra tamb�m o uso de coment�rios em uma �nica linha     *
  *										   *
  *                                                           *
  *                   Primeiro programa                       *
  *************************************************************
*/
/* Prog1.C */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()	/* fun��o main */
{ /* inicio do corpo da fun��o main */
    	printf("Primeiro programa."); /* chamada a fun��o printf */
	system("PAUSE"); /* chamada a fun��o system */
	return 0;
}/* fim do corpo da fun��o main */

